package com.deathtelemetry.telemetry;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.damagesource.DamageSource;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Handles two-way serialization of player flight telemetry into and out of NBT.
 */
public class TelemetrySerializer {

    public static final String KEY_VICTIM_NAME = "VictimName";
    public static final String KEY_VICTIM_UUID = "VictimUUID";
    public static final String KEY_DEATH_TIMESTAMP = "DeathTimestamp";
    public static final String KEY_DEATH_TICK = "DeathTick";
    public static final String KEY_POS_X = "DeathX";
    public static final String KEY_POS_Y = "DeathY";
    public static final String KEY_POS_Z = "DeathZ";
    public static final String KEY_DIMENSION = "Dimension";
    public static final String KEY_FATAL_DAMAGE = "FatalDamageType";
    public static final String KEY_DEATH_MESSAGE = "DeathMessage";
    public static final String KEY_SAMPLE_INTERVAL = "SampleIntervalTicks";
    public static final String KEY_SNAPSHOTS = "Snapshots";

    public static final String KEY_SNAP_TICK = "Tick";
    public static final String KEY_SNAP_TIMESTAMP = "Timestamp";
    public static final String KEY_SNAP_HEALTH = "Health";
    public static final String KEY_SNAP_X_VEL = "XVelocity";
    public static final String KEY_SNAP_Y_VEL = "YVelocity";
    public static final String KEY_SNAP_Z_VEL = "ZVelocity";
    public static final String KEY_SNAP_DAMAGE_LIST = "DamageRecords";
    public static final String KEY_DMG_TYPE = "Type";
    public static final String KEY_DMG_AMOUNT = "Amount";

    /**
     * Serializes player state and rolling telemetry buffer into a CompoundTag.
     */
    public static CompoundTag serialize(
            ServerPlayer player,
            PlayerTelemetryHolder holder,
            DamageSource fatalDamageSource
    ) {
        CompoundTag root = new CompoundTag();

        // 1. Player & Environment Metadata
        root.putString(KEY_VICTIM_NAME, player.getName().getString());
        root.putString(KEY_VICTIM_UUID, player.getStringUUID());
        root.putLong(KEY_DEATH_TIMESTAMP, System.currentTimeMillis());
        root.putLong(KEY_DEATH_TICK, player.level().getGameTime());
        root.putDouble(KEY_POS_X, Math.round(player.getX() * 100.0) / 100.0);
        root.putDouble(KEY_POS_Y, Math.round(player.getY() * 100.0) / 100.0);
        root.putDouble(KEY_POS_Z, Math.round(player.getZ() * 100.0) / 100.0);
        root.putString(KEY_DIMENSION, formatDimensionName(player.level().dimension().identifier().toString()));

        // 2. Fatal Cause of Death
        String fatalType = fatalDamageSource != null
                ? TelemetryServerHandler.resolveDamageTypeName(fatalDamageSource)
                : "unknown";
        root.putString(KEY_FATAL_DAMAGE, fatalType);
        root.putString(KEY_DEATH_MESSAGE, player.getCombatTracker().getDeathMessage().getString());
        root.putInt(KEY_SAMPLE_INTERVAL, com.deathtelemetry.config.ModConfig.get().getSampleIntervalTicks());

        // 3. Rolling Telemetry Buffer Snapshots
        ListTag snapshotListTag = new ListTag();
        List<TelemetrySnapshot> snapshots = holder.getTelemetryBuffer().exportChronologicalSnapshots();

        for (TelemetrySnapshot snapshot : snapshots) {
            CompoundTag snapTag = new CompoundTag();
            snapTag.putLong(KEY_SNAP_TICK, snapshot.getTick());
            snapTag.putLong(KEY_SNAP_TIMESTAMP, snapshot.getTimestampMillis());
            snapTag.putFloat(KEY_SNAP_HEALTH, snapshot.getHealth());
            snapTag.putDouble(KEY_SNAP_X_VEL, snapshot.getXVelocity());
            snapTag.putDouble(KEY_SNAP_Y_VEL, snapshot.getYVelocity());
            snapTag.putDouble(KEY_SNAP_Z_VEL, snapshot.getZVelocity());

            if (snapshot.hasDamage()) {
                ListTag damageListTag = new ListTag();
                for (DamageRecord record : snapshot.getDamageRecords()) {
                    CompoundTag dmgTag = new CompoundTag();
                    dmgTag.putString(KEY_DMG_TYPE, record.damageTypeId());
                    dmgTag.putFloat(KEY_DMG_AMOUNT, record.amount());
                    damageListTag.add(dmgTag);
                }
                snapTag.put(KEY_SNAP_DAMAGE_LIST, damageListTag);
            }

            snapshotListTag.add(snapTag);
        }

        root.put(KEY_SNAPSHOTS, snapshotListTag);
        return root;
    }

    /**
     * Deserializes CompoundTag back into a structured DeathReportData object.
     */
    public static DeathReportData deserialize(CompoundTag tag) {
        if (tag == null) return null;

        String victimName = tag.getStringOr(KEY_VICTIM_NAME, "");
        String victimUuid = tag.getStringOr(KEY_VICTIM_UUID, "");
        long timestamp = tag.getLongOr(KEY_DEATH_TIMESTAMP, 0L);
        long tick = tag.getLongOr(KEY_DEATH_TICK, 0L);
        double x = tag.getDoubleOr(KEY_POS_X, 0.0);
        double y = tag.getDoubleOr(KEY_POS_Y, 0.0);
        double z = tag.getDoubleOr(KEY_POS_Z, 0.0);
        String dimension = formatDimensionName(tag.getStringOr(KEY_DIMENSION, ""));
        String fatalDamage = tag.getStringOr(KEY_FATAL_DAMAGE, "");
        String deathMessage = tag.getStringOr(KEY_DEATH_MESSAGE, "");
        int interval = tag.getIntOr(KEY_SAMPLE_INTERVAL, 10);

        List<TelemetrySnapshot> snapshots = new ArrayList<>();
        ListTag list = tag.getListOrEmpty(KEY_SNAPSHOTS);
        for (int i = 0; i < list.size(); i++) {
            CompoundTag snapTag = list.getCompoundOrEmpty(i);
            TelemetrySnapshot snap = new TelemetrySnapshot();
            snap.set(
                    snapTag.getLongOr(KEY_SNAP_TICK, 0L),
                    snapTag.getLongOr(KEY_SNAP_TIMESTAMP, 0L),
                    snapTag.getFloatOr(KEY_SNAP_HEALTH, 0.0f),
                    snapTag.getDoubleOr(KEY_SNAP_X_VEL, 0.0),
                    snapTag.getDoubleOr(KEY_SNAP_Y_VEL, 0.0),
                    snapTag.getDoubleOr(KEY_SNAP_Z_VEL, 0.0)
            );

            ListTag dmgList = snapTag.getListOrEmpty(KEY_SNAP_DAMAGE_LIST);
            for (int j = 0; j < dmgList.size(); j++) {
                CompoundTag dmgTag = dmgList.getCompoundOrEmpty(j);
                snap.addDamageRecord(
                        dmgTag.getStringOr(KEY_DMG_TYPE, ""),
                        dmgTag.getFloatOr(KEY_DMG_AMOUNT, 0.0f)
                );
            }
            snapshots.add(snap);
        }

        return new DeathReportData(
                victimName,
                victimUuid,
                timestamp,
                tick,
                x,
                y,
                z,
                dimension,
                fatalDamage,
                deathMessage,
                interval,
                snapshots
        );
    }

    /**
     * Formats dimension identifiers (e.g. "minecraft:overworld") into clean human-readable names.
     */
    public static String formatDimensionName(String dimensionId) {
        if (dimensionId == null || dimensionId.isBlank()) {
            return "Unknown";
        }

        String path = dimensionId.contains(":") ? dimensionId.substring(dimensionId.indexOf(':') + 1) : dimensionId;

        return switch (path.toLowerCase(Locale.ROOT)) {
            case "overworld" -> "Overworld";
            case "the_nether", "nether" -> "The Nether";
            case "the_end", "end" -> "The End";
            default -> {
                String[] words = path.split("[_\\-\\s.]+");
                StringBuilder sb = new StringBuilder();
                for (String word : words) {
                    if (!word.isEmpty()) {
                        if (!sb.isEmpty()) sb.append(" ");
                        sb.append(Character.toUpperCase(word.charAt(0)));
                        if (word.length() > 1) {
                            sb.append(word.substring(1).toLowerCase(Locale.ROOT));
                        }
                    }
                }
                yield sb.isEmpty() ? path : sb.toString();
            }
        };
    }

    /**
     * Returns a translatable or formatted Component for the dimension name.
     */
    public static Component getDimensionComponent(String dimensionId) {
        if (dimensionId == null || dimensionId.isBlank()) {
            return Component.translatable("death_telemetry.damage.unknown");
        }

        String normalized = dimensionId.toLowerCase(Locale.ROOT).trim();
        if (normalized.contains(":")) {
            normalized = normalized.substring(normalized.indexOf(':') + 1);
        }

        if (normalized.equals("overworld")) {
            return Component.translatable("death_telemetry.dimension.overworld");
        } else if (normalized.equals("the_nether") || normalized.equals("nether") || normalized.equals("the nether")) {
            return Component.translatable("death_telemetry.dimension.the_nether");
        } else if (normalized.equals("the_end") || normalized.equals("end") || normalized.equals("the end")) {
            return Component.translatable("death_telemetry.dimension.the_end");
        }

        return Component.literal(formatDimensionName(dimensionId));
    }
}
