package com.deathtelemetry.client.gui;

import com.deathtelemetry.telemetry.DamageRecord;
import com.deathtelemetry.telemetry.DeathReportData;
import com.deathtelemetry.telemetry.TelemetrySerializer;
import com.deathtelemetry.telemetry.TelemetryServerHandler;
import com.deathtelemetry.telemetry.TelemetrySnapshot;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Custom Minecraft-styled HUD Screen that renders pre-mortem flight recorder telemetry,
 * including health trajectory, fall/descent rate graphs, damage markers, and interactive hover tooltips.
 */
@Environment(EnvType.CLIENT)
public class TelemetryReportScreen extends Screen {
    private static final int GUI_WIDTH = 380;
    private static final int GUI_HEIGHT = 270;

    private static final DateTimeFormatter TIME_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")
            .withZone(ZoneId.systemDefault());

    private final DeathReportData data;

    public TelemetryReportScreen(DeathReportData data) {
        super(Component.translatable("gui.death_telemetry.title"));
        this.data = data;
    }

    @Override
    protected void init() {
        super.init();
        int left = (this.width - GUI_WIDTH) / 2;
        int top = (this.height - GUI_HEIGHT) / 2;

        // Exit Button (Top right)
        this.addRenderableWidget(
                Button.builder(Component.translatable("gui.death_telemetry.button.exit"), button -> this.onClose())
                        .bounds(left + GUI_WIDTH - 64, top + 4, 50, 16)
                        .build()
        );

        // Close Button
        this.addRenderableWidget(
                Button.builder(Component.translatable("gui.death_telemetry.button.close"), button -> this.onClose())
                        .bounds(left + GUI_WIDTH - 64, top + GUI_HEIGHT - 22, 50, 16)
                        .build()
        );
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor extractor, int mouseX, int mouseY, float delta) {
        super.extractRenderState(extractor, mouseX, mouseY, delta);

        int left = (this.width - GUI_WIDTH) / 2;
        int top = (this.height - GUI_HEIGHT) / 2;

        // 1. Outer Chassis & Frame
        drawChassis(extractor, left, top, GUI_WIDTH, GUI_HEIGHT);

        // 2. Header & Metadata
        drawHeader(extractor, left, top);

        // 3. Telemetry Graphs
        int graphX = left + 16;
        int graphWidth = GUI_WIDTH - 32;
        int graphHeight = 36;

        int healthY = top + 74;
        drawHealthGraph(extractor, graphX, healthY, graphWidth, graphHeight);

        int velY = top + 126;
        drawVelocityGraph(extractor, graphX, velY, graphWidth, graphHeight);

        int xzVelY = top + 178;
        drawXZVelocityGraph(extractor, graphX, xzVelY, graphWidth, graphHeight);

        // 4. Time Scale Labels (X-Axis)
        drawTimeScale(extractor, graphX, xzVelY + graphHeight + 3, graphWidth);

        // 5. Footer Information
        drawFooter(extractor, left, top);

        // 6. Interactive Cursor & Tooltip on Graph Hover
        drawHoverInspection(extractor, mouseX, mouseY, graphX, healthY, xzVelY + graphHeight, graphWidth);
    }

    private void drawChassis(GuiGraphicsExtractor extractor, int x, int y, int w, int h) {
        // Drop shadow / outer border
        extractor.fill(x - 2, y - 2, x + w + 2, y + h + 2, 0xFF000000);

        // Beveled outer metallic border
        extractor.fill(x - 1, y - 1, x + w + 1, y + h + 1, 0xFF3E4349);
        extractor.fill(x, y, x + w, y + h, 0xFF22262B);

        // Inner dark panel body
        extractor.fill(x + 2, y + 2, x + w - 2, y + h - 2, 0xFA121518);

        // Header plate
        extractor.fill(x + 2, y + 2, x + w - 2, y + 24, 0xFF191D22);
        extractor.fill(x + 2, y + 24, x + w - 2, y + 25, 0xFF353B42);
    }

    private void drawHeader(GuiGraphicsExtractor extractor, int x, int y) {
        // Title
        extractor.text(this.font, Component.translatable("gui.death_telemetry.header.title"), x + 10, y + 8, 0xFFFFFFFF, true);

        // Victim Details & Environment
        String timeStr = TIME_FORMATTER.format(Instant.ofEpochMilli(data.deathTimestamp()));
        extractor.text(
                this.font,
                Component.translatable("gui.death_telemetry.header.victim_time", data.victimName(), timeStr),
                x + 10, y + 27, 0xFFFFFFFF, false
        );

        Component dimensionComp = TelemetrySerializer.getDimensionComponent(data.dimension());
        String coordsStr = String.format(Locale.ROOT, "%.1f, %.1f, %.1f", data.x(), data.y(), data.z());
        extractor.text(
                this.font,
                Component.translatable("gui.death_telemetry.header.location", coordsStr, dimensionComp),
                x + 10, y + 38, 0xFFFFFFFF, false
        );

        // Fatal cause banner
        extractor.text(
                this.font,
                Component.translatable("gui.death_telemetry.header.fatal_cause", data.deathMessage()),
                x + 10, y + 49, 0xFFFFFFFF, false
        );
    }

    private void drawHealthGraph(GuiGraphicsExtractor extractor, int x, int y, int w, int h) {
        // Label
        extractor.text(this.font, Component.translatable("gui.death_telemetry.graph.health"), x, y - 9, 0xFFFFFFFF, false);

        // Background box
        extractor.fill(x, y, x + w, y + h, 0xFF0A0C0E);
        extractor.fill(x, y, x + w, y + 1, 0xFF1E2328);
        extractor.fill(x, y + h - 1, x + w, y + h, 0xFF1E2328);

        // 10 HP gridline
        int midY = y + h / 2;
        extractor.fill(x, midY, x + w, midY + 1, 0x1EFFFFFF);
        extractor.text(this.font, Component.literal("§810"), x + w - 14, midY - 4, 0xFFFFFFFF, false);

        List<TelemetrySnapshot> snapshots = data.snapshots();
        if (snapshots.isEmpty()) return;

        int count = snapshots.size();
        float colWidth = (float) w / count;

        int prevPx = -1;
        int prevPy = -1;

        for (int i = 0; i < count; i++) {
            TelemetrySnapshot snap = snapshots.get(i);
            float health = Math.max(0.0f, Math.min(20.0f, snap.getHealth()));

            int px = x + Math.round((i + 0.5f) * colWidth);
            int py = (y + h - 3) - Math.round((health / 20.0f) * (h - 6));

            int color = 0xFF44CC44; // Green
            if (health <= 6.0f) {
                color = 0xFFFF3333; // Red
            } else if (health <= 12.0f) {
                color = 0xFFFFBB22; // Yellow
            }

            // Damage incident marker at the top of the graph column
            if (snap.hasDamage()) {
                extractor.fill(px - 1, y, px + 2, y + 3, 0xFFFF2222);
            }

            // Connect previous point with line
            if (prevPx >= 0) {
                drawLine(extractor, prevPx, prevPy, px, py, color);
            }

            // Node dot
            extractor.fill(px - 1, py - 1, px + 2, py + 2, color);

            prevPx = px;
            prevPy = py;
        }
    }

    private void drawVelocityGraph(GuiGraphicsExtractor extractor, int x, int y, int w, int h) {
        // Label
        extractor.text(this.font, Component.translatable("gui.death_telemetry.graph.y_velocity"), x, y - 9, 0xFFFFFFFF, false);

        // Background box
        extractor.fill(x, y, x + w, y + h, 0xFF0A0C0E);
        extractor.fill(x, y, x + w, y + 1, 0xFF1E2328);
        extractor.fill(x, y + h - 1, x + w, y + h, 0xFF1E2328);

        // Zero velocity baseline (centered slightly high to emphasize descent)
        int zeroY = y + 11;
        extractor.fill(x, zeroY, x + w, zeroY + 1, 0xFF3E4A56);
        extractor.text(this.font, Component.literal("§80.0"), x + w - 18, zeroY - 4, 0xFFFFFFFF, false);

        // Freefall danger threshold line
        double dangerThreshold = com.deathtelemetry.config.ModConfig.get().getFreefallWarningThreshold();
        int dangerY = zeroY + (int) Math.min(y + h - 1 - zeroY, Math.round(-dangerThreshold * 16.0));
        extractor.fill(x, dangerY, x + w, dangerY + 1, 0x44FF2222);
        extractor.text(this.font, Component.translatable("gui.death_telemetry.graph.descent_risk"), x + 4, dangerY - 4, 0xFFFFFFFF, false);

        List<TelemetrySnapshot> snapshots = data.snapshots();
        if (snapshots.isEmpty()) return;

        float colWidth = (float) w / snapshots.size();

        for (int i = 0; i < snapshots.size(); i++) {
            TelemetrySnapshot snap = snapshots.get(i);
            double yVel = snap.getYVelocity();
            if (Math.abs(yVel) < 0.001 || (yVel < 0.0 && yVel >= -0.085)) {
                // Not moving vertically - no bar needed
                continue;
            }

            int barX1 = x + Math.round(i * colWidth);
            int barX2 = Math.max(barX1 + 1, x + Math.round((i + 1) * colWidth) - 1);

            int barY1, barY2, color;

            if (yVel >= 0.0) {
                // Ascending / Jump
                int barHeight = (int) Math.min(zeroY - y, Math.round(yVel * 20.0));
                barY1 = zeroY - barHeight;
                barY2 = zeroY;
                color = 0xFF33CCFF; // Cyan
            } else {
                // Descending / Fall
                int barHeight = (int) Math.min(y + h - 1 - zeroY, Math.round(-yVel * 16.0));
                barY1 = zeroY + 1;
                barY2 = zeroY + 1 + barHeight;

                if (yVel < -0.8) {
                    color = 0xFFFF2222; // Terminal fall (Red)
                } else if (yVel < -0.4) {
                    color = 0xFFFFAA00; // Moderate drop (Orange)
                } else {
                    color = 0xFF55BBDD; // Light descent (Blue)
                }
            }

            extractor.fill(barX1, barY1, barX2, barY2, color);
        }
    }

    private void drawXZVelocityGraph(GuiGraphicsExtractor extractor, int x, int y, int w, int h) {
        // Label with color legend
        extractor.text(this.font, Component.translatable("gui.death_telemetry.graph.xz_velocity"), x, y - 9, 0xFFFFFFFF, false);

        // Background box
        extractor.fill(x, y, x + w, y + h, 0xFF0A0C0E);
        extractor.fill(x, y, x + w, y + 1, 0xFF1E2328);
        extractor.fill(x, y + h - 1, x + w, y + h, 0xFF1E2328);

        // Zero velocity baseline (centered)
        int zeroY = y + h / 2;
        extractor.fill(x, zeroY, x + w, zeroY + 1, 0xFF3E4A56);
        extractor.text(this.font, Component.literal("§80.0"), x + w - 18, zeroY - 4, 0xFFFFFFFF, false);

        List<TelemetrySnapshot> snapshots = data.snapshots();
        if (snapshots.isEmpty()) return;

        int count = snapshots.size();
        float colWidth = (float) w / count;
        int maxTravel = (h / 2) - 3;

        int prevXx = -1, prevXy = -1;
        int prevZx = -1, prevZy = -1;

        int colorX = 0xFFFF4444; // Bright Red for X-Velocity
        int colorZ = 0xFFCC44FF; // Vibrant Purple for Z-Velocity

        for (int i = 0; i < count; i++) {
            TelemetrySnapshot snap = snapshots.get(i);
            double xVel = snap.getXVelocity();
            double zVel = snap.getZVelocity();

            int px = x + Math.round((i + 0.5f) * colWidth);

            int pyX = zeroY - (int) Math.max(-maxTravel, Math.min(maxTravel, Math.round(xVel * 35.0)));
            int pyZ = zeroY - (int) Math.max(-maxTravel, Math.min(maxTravel, Math.round(zVel * 35.0)));

            // Draw X-Velocity line & point
            if (prevXx >= 0) {
                drawLine(extractor, prevXx, prevXy, px, pyX, colorX);
            }
            extractor.fill(px - 1, pyX - 1, px + 2, pyX + 2, colorX);

            // Draw Z-Velocity line & point
            if (prevZx >= 0) {
                drawLine(extractor, prevZx, prevZy, px, pyZ, colorZ);
            }
            extractor.fill(px - 1, pyZ - 1, px + 2, pyZ + 2, colorZ);

            prevXx = px;
            prevXy = pyX;
            prevZx = px;
            prevZy = pyZ;
        }
    }

    private void drawLine(GuiGraphicsExtractor extractor, int x0, int y0, int x1, int y1, int color) {
        int dx = Math.abs(x1 - x0);
        int dy = Math.abs(y1 - y0);
        int sx = x0 < x1 ? 1 : -1;
        int sy = y0 < y1 ? 1 : -1;
        int err = dx - dy;

        while (true) {
            extractor.fill(x0, y0, x0 + 1, y0 + 1, color);
            if (x0 == x1 && y0 == y1) break;
            int e2 = 2 * err;
            if (e2 > -dy) {
                err -= dy;
                x0 += sx;
            }
            if (e2 < dx) {
                err += dx;
                y0 += sy;
            }
        }
    }

    private void drawTimeScale(GuiGraphicsExtractor extractor, int x, int y, int w) {
        int snapshotCount = data.snapshots().size();
        double totalSeconds = snapshotCount > 1
                ? (snapshotCount - 1) * (data.sampleIntervalTicks() / 20.0)
                : (snapshotCount * (data.sampleIntervalTicks() / 20.0));
        if (totalSeconds < 0.1) totalSeconds = 10.0;

        String fullTimeStr = String.format(Locale.ROOT, "§8-%.1fs", totalSeconds);
        String halfTimeStr = String.format(Locale.ROOT, "§8-%.1fs", totalSeconds / 2.0);
        extractor.text(this.font, Component.literal(fullTimeStr), x, y, 0xFFFFFFFF, false);
        extractor.text(this.font, Component.literal(halfTimeStr), x + w / 2 - 10, y, 0xFFFFFFFF, false);
        Component fatalText = Component.translatable("gui.death_telemetry.graph.fatal_marker");
        int fatalWidth = this.font.width(fatalText);
        extractor.text(this.font, fatalText, x + w - fatalWidth, y, 0xFFFFFFFF, false);
    }

    private void drawFooter(GuiGraphicsExtractor extractor, int x, int y) {
        int footY = y + GUI_HEIGHT - 18;
        String intervalSec = String.format(Locale.ROOT, "%.1f", data.sampleIntervalTicks() / 20.0);
        extractor.text(
                this.font,
                Component.translatable("gui.death_telemetry.footer.telemetry_info", data.snapshots().size(), intervalSec),
                x + 10, footY, 0xFFFFFFFF, false
        );
    }

    private void drawHoverInspection(GuiGraphicsExtractor extractor, int mouseX, int mouseY, int gx, int topY, int bottomY, int gw) {
        List<TelemetrySnapshot> snapshots = data.snapshots();
        if (snapshots.isEmpty()) return;

        // Check if cursor is over the telemetry graph column area
        if (mouseX >= gx && mouseX < gx + gw && mouseY >= topY && mouseY <= bottomY) {
            float colWidth = (float) gw / snapshots.size();
            int sampleIndex = (int) ((mouseX - gx) / colWidth);
            sampleIndex = Math.max(0, Math.min(snapshots.size() - 1, sampleIndex));

            TelemetrySnapshot snap = snapshots.get(sampleIndex);

            // Draw vertical inspection cursor beam
            int cursorX = gx + Math.round(sampleIndex * colWidth);
            extractor.fill(cursorX, topY, cursorX + Math.max(1, Math.round(colWidth)), bottomY, 0x33FFFFFF);

            // Calculate seconds before death
            double secondsBeforeDeath = (snapshots.size() - 1 - sampleIndex) * (data.sampleIntervalTicks() / 20.0);

            List<Component> tooltip = new ArrayList<>();
            tooltip.add(Component.translatable("gui.death_telemetry.tooltip.time", String.format(Locale.ROOT, "%.1f", secondsBeforeDeath)));
            tooltip.add(Component.translatable("gui.death_telemetry.tooltip.health", String.format(Locale.ROOT, "%.1f", snap.getHealth())));

            double yVel = snap.getYVelocity();
            if (Math.abs(yVel) < 0.001 || (yVel < 0.0 && yVel >= -0.085)) {
                yVel = 0.0;
            }

            double warningThreshold = com.deathtelemetry.config.ModConfig.get().getFreefallWarningThreshold();
            Component velWarning = yVel < warningThreshold
                    ? Component.translatable("gui.death_telemetry.tooltip.freefall_warning")
                    : Component.empty();
            tooltip.add(Component.translatable("gui.death_telemetry.tooltip.y_velocity", String.format(Locale.ROOT, "%.2f", yVel), velWarning));

            double xVel = snap.getXVelocity();
            double zVel = snap.getZVelocity();
            tooltip.add(Component.translatable("gui.death_telemetry.tooltip.xz_velocity", String.format(Locale.ROOT, "%.2f", xVel), String.format(Locale.ROOT, "%.2f", zVel)));

            if (snap.hasDamage()) {
                tooltip.add(Component.translatable("gui.death_telemetry.tooltip.damage_events"));
                for (DamageRecord record : snap.getDamageRecords()) {
                    Component dmgComponent = TelemetryServerHandler.getDamageTypeComponent(record.damageTypeId());
                    tooltip.add(Component.translatable("gui.death_telemetry.tooltip.damage_entry", dmgComponent, String.format(Locale.ROOT, "%.1f", record.amount())));
                }
            } else {
                tooltip.add(Component.translatable("gui.death_telemetry.tooltip.damage_none"));
            }

            extractor.setComponentTooltipForNextFrame(this.font, tooltip, mouseX, mouseY);
        }
    }

    @Override
    public boolean isPauseScreen() {
        return com.deathtelemetry.config.ModConfig.get().isPauseGameOnScreen();
    }
}
