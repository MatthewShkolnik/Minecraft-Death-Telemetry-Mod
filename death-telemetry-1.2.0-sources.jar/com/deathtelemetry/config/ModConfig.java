package com.deathtelemetry.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * Global configuration for Death Telemetry.
 * Loads and persists settings to and from config.json.
 */
public class ModConfig {
    private static final Logger LOGGER = LoggerFactory.getLogger("death_telemetry");
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static ModConfig INSTANCE = new ModConfig();

    // --- Telemetry Recording Settings ---
    private int snapshotCount = 20;
    private int sampleIntervalTicks = 10;

    // --- Item Drop Settings ---
    private boolean dropOnDeath = true;
    private boolean invulnerableItem = true;
    private boolean glowingItem = false;
    private boolean preventDespawn = true;
    private boolean respectKeepInventory = false;

    // --- Item Lore Settings ---
    private boolean showVictimInLore = true;
    private boolean showCauseInLore = true;
    private boolean showCoordinatesInLore = true;

    // --- Logging Settings ---
    private boolean logDeathCoordinates = true;

    // --- Client / HUD Display Settings ---
    private double freefallWarningThreshold = -0.6;
    private boolean pauseGameOnScreen = false;

    public static ModConfig get() {
        if (INSTANCE == null) {
            INSTANCE = new ModConfig();
        }
        return INSTANCE;
    }

    /**
     * Resolves the primary config file path.
     * Looks in:
     * 1. <configDir>/death_telemetry/config.json
     * 2. <configDir>/death_telemetry.json
     * 3. <configDir>/config.json
     * 4. ./config.json
     */
    public static Path resolveConfigPath() {
        try {
            Path configDir = FabricLoader.getInstance().getConfigDir();

            Path subDirConfig = configDir.resolve("death_telemetry").resolve("config.json");
            if (Files.exists(subDirConfig)) {
                return subDirConfig;
            }

            Path modConfig = configDir.resolve("death_telemetry.json");
            if (Files.exists(modConfig)) {
                return modConfig;
            }

            Path genericConfig = configDir.resolve("config.json");
            if (Files.exists(genericConfig)) {
                return genericConfig;
            }

            Path rootConfig = Path.of("config.json");
            if (Files.exists(rootConfig)) {
                return rootConfig;
            }

            // Default save location
            return subDirConfig;
        } catch (Throwable t) {
            // Fallback to local config.json if FabricLoader is unavailable (e.g. unit tests)
            return Path.of("config.json");
        }
    }

    /**
     * Loads config from disk or creates default if missing.
     */
    public static void load() {
        Path configPath = resolveConfigPath();
        if (Files.exists(configPath)) {
            try (Reader reader = Files.newBufferedReader(configPath)) {
                ModConfig loaded = GSON.fromJson(reader, ModConfig.class);
                if (loaded != null) {
                    loaded.sanitize();
                    INSTANCE = loaded;
                    LOGGER.info("Loaded configuration from {}", configPath.toAbsolutePath());
                    return;
                }
            } catch (Exception e) {
                LOGGER.error("Failed to read configuration from {}, using defaults: {}", configPath, e.getMessage());
            }
        }

        // Config file does not exist or failed to load: initialize defaults and save
        INSTANCE = new ModConfig();
        INSTANCE.sanitize();
        save();
    }

    /**
     * Saves the current config state to disk.
     */
    public static void save() {
        Path configPath = resolveConfigPath();
        try {
            if (configPath.getParent() != null) {
                Files.createDirectories(configPath.getParent());
            }
            try (Writer writer = Files.newBufferedWriter(configPath)) {
                GSON.toJson(INSTANCE, writer);
            }
            LOGGER.info("Saved configuration to {}", configPath.toAbsolutePath());
        } catch (IOException e) {
            LOGGER.error("Failed to save configuration to {}: {}", configPath, e.getMessage());
        }
    }

    /**
     * Validates and bounds all configuration values.
     */
    public void sanitize() {
        // snapshotCount clamped between 5 and 600 (2.5 seconds to 5 minutes)
        if (this.snapshotCount < 5) {
            LOGGER.warn("snapshotCount {} is too low; clamping to 5", this.snapshotCount);
            this.snapshotCount = 5;
        } else if (this.snapshotCount > 600) {
            LOGGER.warn("snapshotCount {} is too high; clamping to 600", this.snapshotCount);
            this.snapshotCount = 600;
        }

        // sampleIntervalTicks clamped between 1 (20 Hz) and 100 (5 seconds)
        if (this.sampleIntervalTicks < 1) {
            LOGGER.warn("sampleIntervalTicks {} is too low; clamping to 1", this.sampleIntervalTicks);
            this.sampleIntervalTicks = 1;
        } else if (this.sampleIntervalTicks > 100) {
            LOGGER.warn("sampleIntervalTicks {} is too high; clamping to 100", this.sampleIntervalTicks);
            this.sampleIntervalTicks = 100;
        }

        // freefallWarningThreshold must be negative
        if (this.freefallWarningThreshold > 0) {
            this.freefallWarningThreshold = -Math.abs(this.freefallWarningThreshold);
        }
        if (this.freefallWarningThreshold == 0) {
            this.freefallWarningThreshold = -0.6;
        }
    }

    // --- Getters and Setters ---

    public int getSnapshotCount() {
        return snapshotCount;
    }

    public void setSnapshotCount(int snapshotCount) {
        this.snapshotCount = snapshotCount;
    }

    public int getSampleIntervalTicks() {
        return sampleIntervalTicks;
    }

    public void setSampleIntervalTicks(int sampleIntervalTicks) {
        this.sampleIntervalTicks = sampleIntervalTicks;
    }

    public boolean isDropOnDeath() {
        return dropOnDeath;
    }

    public void setDropOnDeath(boolean dropOnDeath) {
        this.dropOnDeath = dropOnDeath;
    }

    public boolean isInvulnerableItem() {
        return invulnerableItem;
    }

    public void setInvulnerableItem(boolean invulnerableItem) {
        this.invulnerableItem = invulnerableItem;
    }

    public boolean isGlowingItem() {
        return glowingItem;
    }

    public void setGlowingItem(boolean glowingItem) {
        this.glowingItem = glowingItem;
    }

    public boolean isPreventDespawn() {
        return preventDespawn;
    }

    public void setPreventDespawn(boolean preventDespawn) {
        this.preventDespawn = preventDespawn;
    }

    public boolean isRespectKeepInventory() {
        return respectKeepInventory;
    }

    public void setRespectKeepInventory(boolean respectKeepInventory) {
        this.respectKeepInventory = respectKeepInventory;
    }

    public boolean isShowVictimInLore() {
        return showVictimInLore;
    }

    public void setShowVictimInLore(boolean showVictimInLore) {
        this.showVictimInLore = showVictimInLore;
    }

    public boolean isShowCauseInLore() {
        return showCauseInLore;
    }

    public void setShowCauseInLore(boolean showCauseInLore) {
        this.showCauseInLore = showCauseInLore;
    }

    public boolean isShowCoordinatesInLore() {
        return showCoordinatesInLore;
    }

    public void setShowCoordinatesInLore(boolean showCoordinatesInLore) {
        this.showCoordinatesInLore = showCoordinatesInLore;
    }

    public boolean isLogDeathCoordinates() {
        return logDeathCoordinates;
    }

    public void setLogDeathCoordinates(boolean logDeathCoordinates) {
        this.logDeathCoordinates = logDeathCoordinates;
    }

    public double getFreefallWarningThreshold() {
        return freefallWarningThreshold;
    }

    public void setFreefallWarningThreshold(double freefallWarningThreshold) {
        this.freefallWarningThreshold = freefallWarningThreshold;
    }

    public boolean isPauseGameOnScreen() {
        return pauseGameOnScreen;
    }

    public void setPauseGameOnScreen(boolean pauseGameOnScreen) {
        this.pauseGameOnScreen = pauseGameOnScreen;
    }
}
