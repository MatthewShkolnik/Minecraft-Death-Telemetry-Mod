package com.deathtelemetry.event;

import com.deathtelemetry.DeathTelemetryMod;
import com.deathtelemetry.item.AutopsyReportItem;
import com.deathtelemetry.item.ModItems;
import com.deathtelemetry.telemetry.PlayerTelemetryHolder;
import com.deathtelemetry.telemetry.TelemetrySerializer;
import com.deathtelemetry.telemetry.TelemetryServerHandler;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.minecraft.ChatFormatting;
import net.minecraft.core.component.DataComponents;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.ItemLore;

import java.util.List;
import java.util.Locale;

/**
 * Intercepts player death, generates the "Autopsy Report" Black Box item with serialized
 * telemetry NBT data, and drops it directly at the player's death coordinates.
 */
public class DeathEventHandler {

    public static void register() {
        ServerLivingEntityEvents.AFTER_DEATH.register((entity, damageSource) -> {
            if (entity instanceof ServerPlayer player && player instanceof PlayerTelemetryHolder holder) {
                handlePlayerDeath(player, holder, damageSource);
            }
        });
    }

    private static void handlePlayerDeath(
            ServerPlayer player,
            PlayerTelemetryHolder holder,
            DamageSource damageSource
    ) {
        com.deathtelemetry.config.ModConfig config = com.deathtelemetry.config.ModConfig.get();

        // 1. Ensure the fatal damage blow is recorded in the pending buffer
        if (damageSource != null) {
            String fatalTypeName = TelemetryServerHandler.resolveDamageTypeName(damageSource);
            holder.recordDamage(fatalTypeName, player.getMaxHealth());
        }

        // 2. Commit final snapshot at the exact moment of death
        holder.forceSample();

        // Check if dropping the black box on death is disabled in config
        if (!config.isDropOnDeath()) {
            holder.resetTelemetry();
            return;
        }

        // Check if keepInventory gamerule should be respected
        if (config.isRespectKeepInventory() && Boolean.TRUE.equals(player.level().getGameRules().get(net.minecraft.world.level.gamerules.GameRules.KEEP_INVENTORY))) {
            holder.resetTelemetry();
            return;
        }

        // 3. Serialize the telemetry buffer into NBT
        CompoundTag telemetryTag = TelemetrySerializer.serialize(player, holder, damageSource);

        // 4. Construct the Black Box "autopsy_report" ItemStack
        ItemStack blackBoxStack = new ItemStack(ModItems.AUTOPSY_REPORT);
        AutopsyReportItem.setTelemetryData(blackBoxStack, telemetryTag);

        // 5. Apply Minecraft 26.3 custom name and descriptive lore
        String victimName = player.getName().getString();
        String deathMessage = player.getCombatTracker().getDeathMessage().getString();

        blackBoxStack.set(
                DataComponents.CUSTOM_NAME,
                Component.translatable("item.death_telemetry.autopsy_report.custom_name", victimName).withStyle(ChatFormatting.GOLD)
        );

        java.util.List<Component> loreLines = new java.util.ArrayList<>();
        if (config.isShowVictimInLore()) {
            loreLines.add(Component.translatable(
                    "item.death_telemetry.autopsy_report.lore.victim",
                    Component.literal(victimName).withStyle(ChatFormatting.WHITE)
            ).withStyle(ChatFormatting.GRAY));
        }
        if (config.isShowCauseInLore()) {
            loreLines.add(Component.translatable(
                    "item.death_telemetry.autopsy_report.lore.cause",
                    Component.literal(deathMessage).withStyle(ChatFormatting.RED)
            ).withStyle(ChatFormatting.GRAY));
        }
        if (config.isShowCoordinatesInLore()) {
            loreLines.add(Component.translatable(
                    "item.death_telemetry.autopsy_report.lore.coordinates",
                    Component.literal(String.format(Locale.ROOT, "%.1f, %.1f, %.1f", player.getX(), player.getY(), player.getZ())).withStyle(ChatFormatting.YELLOW)
            ).withStyle(ChatFormatting.GRAY));
        }
        loreLines.add(Component.translatable("item.death_telemetry.autopsy_report.lore.help").withStyle(ChatFormatting.DARK_GRAY, ChatFormatting.ITALIC));
        blackBoxStack.set(DataComponents.LORE, new ItemLore(loreLines));

        // 6. Spawn ItemEntity at the exact death coordinates
        ServerLevel world = player.level();
        double spawnX = player.getX();
        double spawnY = player.getY() + 0.5;
        double spawnZ = player.getZ();

        ItemEntity itemEntity = new ItemEntity(world, spawnX, spawnY, spawnZ, blackBoxStack);
        itemEntity.setDefaultPickUpDelay();

        if (config.isInvulnerableItem()) {
            itemEntity.setPermanentlyInvulnerable(true); // Protect against lingering explosions / lava
        }
        if (config.isGlowingItem()) {
            itemEntity.setGlowingTag(true); // Highlight dropped item in the world
        }
        if (config.isPreventDespawn()) {
            itemEntity.setUnlimitedLifetime(); // Protect against despawning after 5 minutes
        }

        world.addFreshEntity(itemEntity);

        if (config.isLogDeathCoordinates()) {
            DeathTelemetryMod.LOGGER.info(
                    "Spawned Autopsy Report black box for {} at ({}, {}, {}) in {}",
                    victimName, spawnX, spawnY, spawnZ, world.dimension().identifier()
            );
        }

        // 7. Reset buffer on the dead player entity
        holder.resetTelemetry();
    }
}
