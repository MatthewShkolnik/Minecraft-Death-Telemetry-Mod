package com.deathtelemetry.mixin;

import com.deathtelemetry.config.ModConfig;
import com.deathtelemetry.telemetry.DamageRecord;
import com.deathtelemetry.telemetry.PlayerTelemetryHolder;
import com.deathtelemetry.telemetry.TelemetryRingBuffer;
import com.deathtelemetry.telemetry.TelemetrySnapshot;
import net.minecraft.server.level.ServerPlayer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.ArrayList;
import java.util.List;

/**
 * Attaches the lightweight rolling telemetry ring-buffer to ServerPlayer for Minecraft 26.3.
 * Configured via ModConfig for dynamic snapshot capacity and tick interval.
 */
@Mixin(ServerPlayer.class)
public abstract class ServerPlayerEntityMixin implements PlayerTelemetryHolder {
    @Unique
    private TelemetryRingBuffer death_telemetry$buffer = new TelemetryRingBuffer(ModConfig.get().getSnapshotCount());

    @Unique
    private final List<DamageRecord> death_telemetry$pendingDamage = new ArrayList<>(4);

    @Unique
    private int death_telemetry$tickCounter = 0;

    @Inject(method = "tick", at = @At("TAIL"))
    private void death_telemetry$onPlayerTick(CallbackInfo ci) {
        tickTelemetry();
    }

    @Override
    @Unique
    public void tickTelemetry() {
        death_telemetry$tickCounter++;

        if (death_telemetry$tickCounter >= ModConfig.get().getSampleIntervalTicks()) {
            death_telemetry$tickCounter = 0;
            commitSample();
        }
    }

    @Override
    @Unique
    public void forceSample() {
        death_telemetry$tickCounter = 0;
        commitSample();
    }

    @Unique
    private void commitSample() {
        ServerPlayer player = (ServerPlayer) (Object) this;

        long currentTick = player.level().getGameTime();
        long currentEpochMs = System.currentTimeMillis();
        float health = player.getHealth();
        double xVelocity = player.getDeltaMovement().x;
        double yVelocity = player.getDeltaMovement().y;
        double zVelocity = player.getDeltaMovement().z;

        if (Math.abs(xVelocity) < 0.001) {
            xVelocity = 0.0;
        }
        if (Math.abs(zVelocity) < 0.001) {
            zVelocity = 0.0;
        }

        // In Minecraft physics, entities on the ground retain a downward resting gravity
        // velocity (~ -0.0784 m/s). When on the ground and not jumping, vertical velocity is 0.
        if (player.onGround() && (yVelocity <= 0.0 && yVelocity >= -0.085)) {
            yVelocity = 0.0;
        } else if (Math.abs(yVelocity) < 0.001) {
            yVelocity = 0.0;
        }

        TelemetrySnapshot slot = death_telemetry$buffer.recordSample(
                currentTick,
                currentEpochMs,
                health,
                xVelocity,
                yVelocity,
                zVelocity
        );

        // Transfer all damage sources registered during this 10-tick sample window
        if (!death_telemetry$pendingDamage.isEmpty()) {
            for (DamageRecord record : death_telemetry$pendingDamage) {
                slot.addDamageRecord(record.damageTypeId(), record.amount());
            }
            death_telemetry$pendingDamage.clear();
        }
    }

    @Override
    @Unique
    public void recordDamage(String damageTypeId, float amount) {
        death_telemetry$pendingDamage.add(new DamageRecord(damageTypeId, amount));
    }

    @Override
    @Unique
    public TelemetryRingBuffer getTelemetryBuffer() {
        return death_telemetry$buffer;
    }

    @Override
    @Unique
    public void resetTelemetry() {
        death_telemetry$tickCounter = 0;
        death_telemetry$pendingDamage.clear();
        int targetCapacity = ModConfig.get().getSnapshotCount();
        if (death_telemetry$buffer.capacity() != targetCapacity) {
            death_telemetry$buffer = new TelemetryRingBuffer(targetCapacity);
        } else {
            death_telemetry$buffer.clear();
        }
    }
}
