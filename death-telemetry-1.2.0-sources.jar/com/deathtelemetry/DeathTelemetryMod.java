package com.deathtelemetry;

import com.deathtelemetry.item.ModItems;
import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Main entry point for the Death Telemetry Fabric mod.
 */
public class DeathTelemetryMod implements ModInitializer {
    public static final String MOD_ID = "death_telemetry";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        LOGGER.info("Initializing Death Telemetry mod [{}]", MOD_ID);

        // 1. Load configuration
        com.deathtelemetry.config.ModConfig.load();

        // 2. Register mod items (Autopsy Report black box)
        ModItems.registerModItems();

        // 3. Server lifecycle & telemetry tracking events
        com.deathtelemetry.telemetry.TelemetryServerHandler.register();

        // 4. Death event interceptor & black box spawner
        com.deathtelemetry.event.DeathEventHandler.register();

        // 5. Register admin commands (/death_telemetry reload)
        net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            dispatcher.register(net.minecraft.commands.Commands.literal("death_telemetry")
                    .requires(source -> source.permissions().hasPermission(net.minecraft.server.permissions.Permissions.COMMANDS_ADMIN))
                    .then(net.minecraft.commands.Commands.literal("reload")
                            .executes(context -> {
                                com.deathtelemetry.config.ModConfig.load();
                                context.getSource().sendSuccess(
                                        () -> net.minecraft.network.chat.Component.literal("§a[Death Telemetry] Configuration successfully reloaded from config.json."),
                                        true
                                );
                                return 1;
                            })
                    )
            );
        });
    }
}
