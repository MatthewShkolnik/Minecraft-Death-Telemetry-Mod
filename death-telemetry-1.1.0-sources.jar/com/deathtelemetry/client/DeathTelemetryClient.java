package com.deathtelemetry.client;

import com.deathtelemetry.DeathTelemetryMod;
import com.deathtelemetry.client.gui.TelemetryReportScreen;
import com.deathtelemetry.item.AutopsyReportItem;
import com.deathtelemetry.telemetry.DeathReportData;
import com.deathtelemetry.telemetry.TelemetrySerializer;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.Minecraft;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.item.ItemStack;

/**
 * Client entry point for Death Telemetry.
 * Registers client interaction hooks and opens the telemetry readout GUI.
 */
@Environment(EnvType.CLIENT)
public class DeathTelemetryClient implements ClientModInitializer {

    @Override
    public void onInitializeClient() {
        DeathTelemetryMod.LOGGER.info("Initializing Death Telemetry Client");

        // Hook client use callback from AutopsyReportItem
        AutopsyReportItem.CLIENT_USE_HANDLER = DeathTelemetryClient::openTelemetryScreen;
    }

    /**
     * Unmarshals telemetry NBT from the item stack and opens the Minecraft-styled HUD Screen.
     */
    public static void openTelemetryScreen(ItemStack stack) {
        CompoundTag telemetryTag = AutopsyReportItem.getTelemetryData(stack);
        if (telemetryTag == null) {
            DeathTelemetryMod.LOGGER.warn("Attempted to open telemetry screen but NBT data was null.");
            return;
        }

        DeathReportData data = TelemetrySerializer.deserialize(telemetryTag);
        if (data != null) {
            Minecraft.getInstance().setScreenAndShow(new TelemetryReportScreen(data));
        }
    }
}
