package com.deathtelemetry;

import com.deathtelemetry.item.ModItems;
import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Main entry point for the Death Telemetry Fabric mod.
 */
public class DeathTelemetryMod implements ModInitializer {
    public static final String MOD_ID = "death_telemetry";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        LOGGER.info("Initializing Death Telemetry mod [{}]", MOD_ID);

        // 1. Register mod items (Autopsy Report black box)
        ModItems.registerModItems();

        // 2. Server lifecycle & telemetry tracking events
        com.deathtelemetry.telemetry.TelemetryServerHandler.register();

        // 3. Death event interceptor & black box spawner
        com.deathtelemetry.event.DeathEventHandler.register();
    }
}
