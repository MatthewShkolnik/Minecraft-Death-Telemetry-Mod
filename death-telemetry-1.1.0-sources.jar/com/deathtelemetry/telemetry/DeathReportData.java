package com.deathtelemetry.telemetry;

import java.util.List;

/**
 * High-level data model representing an unmarshalled Autopsy Report (Black Box).
 * Used by client-side GUI and analytics.
 */
public record DeathReportData(
        String victimName,
        String victimUuid,
        long deathTimestamp,
        long deathTick,
        double x,
        double y,
        double z,
        String dimension,
        String fatalDamageType,
        String deathMessage,
        int sampleIntervalTicks,
        List<TelemetrySnapshot> snapshots
) {
}
