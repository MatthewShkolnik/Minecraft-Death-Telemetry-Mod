package com.deathtelemetry.telemetry;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Reusable data slot representing a single telemetry sample window.
 * Designed to be pre-allocated and updated in-place to prevent GC allocations during steady-state ticking.
 */
public class TelemetrySnapshot {
    private long tick;
    private long timestampMillis;
    private float health;
    private double xVelocity;
    private double yVelocity;
    private double zVelocity;
    private final List<DamageRecord> damageRecords;

    public TelemetrySnapshot() {
        this.tick = 0L;
        this.timestampMillis = 0L;
        this.health = 20.0f;
        this.xVelocity = 0.0;
        this.yVelocity = 0.0;
        this.zVelocity = 0.0;
        // Pre-allocate a small initial capacity; damage is sporadic so list stays empty or small
        this.damageRecords = new ArrayList<>(2);
    }

    /**
     * Resets and updates the slot in-place without generating garbage.
     */
    public void set(long tick, long timestampMillis, float health, double xVelocity, double yVelocity, double zVelocity) {
        this.tick = tick;
        this.timestampMillis = timestampMillis;
        this.health = health;
        this.xVelocity = xVelocity;
        this.yVelocity = yVelocity;
        this.zVelocity = zVelocity;
        this.damageRecords.clear();
    }

    public void set(long tick, long timestampMillis, float health, double yVelocity) {
        set(tick, timestampMillis, health, 0.0, yVelocity, 0.0);
    }

    /**
     * Appends a damage record to this sample slot.
     */
    public void addDamageRecord(String damageTypeId, float amount) {
        this.damageRecords.add(new DamageRecord(damageTypeId, amount));
    }

    /**
     * Copies data from another snapshot into this one.
     */
    public void copyFrom(TelemetrySnapshot other) {
        this.tick = other.tick;
        this.timestampMillis = other.timestampMillis;
        this.health = other.health;
        this.xVelocity = other.xVelocity;
        this.yVelocity = other.yVelocity;
        this.zVelocity = other.zVelocity;
        this.damageRecords.clear();
        this.damageRecords.addAll(other.damageRecords);
    }

    /**
     * Creates an immutable, detached clone of this snapshot (useful when serializing on death).
     */
    public TelemetrySnapshot detachedCopy() {
        TelemetrySnapshot copy = new TelemetrySnapshot();
        copy.copyFrom(this);
        return copy;
    }

    public long getTick() {
        return tick;
    }

    public long getTimestampMillis() {
        return timestampMillis;
    }

    public float getHealth() {
        return health;
    }

    public double getXVelocity() {
        if (Math.abs(xVelocity) < 0.001) {
            return 0.0;
        }
        return xVelocity;
    }

    public double getYVelocity() {
        if (yVelocity < 0.0 && yVelocity >= -0.085) {
            return 0.0;
        }
        if (Math.abs(yVelocity) < 0.001) {
            return 0.0;
        }
        return yVelocity;
    }

    public double getZVelocity() {
        if (Math.abs(zVelocity) < 0.001) {
            return 0.0;
        }
        return zVelocity;
    }

    public List<DamageRecord> getDamageRecords() {
        return Collections.unmodifiableList(damageRecords);
    }

    public boolean hasDamage() {
        return !damageRecords.isEmpty();
    }
}
