package com.deathtelemetry.telemetry;

import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.damagesource.DamageSource;

import net.minecraft.world.entity.Entity;

/**
 * Server-side event handler that feeds real-time world events (damage, connections)
 * into the player's telemetry tracker.
 */
public class TelemetryServerHandler {

    public static void register() {
        // Intercept player damage events and record damage type & amount into the pending queue
        ServerLivingEntityEvents.AFTER_DAMAGE.register((entity, source, baseDamage, damageTaken, blocked) -> {
            if (entity instanceof ServerPlayer player && player instanceof PlayerTelemetryHolder holder) {
                String damageTypeName = resolveDamageTypeName(source);
                holder.recordDamage(damageTypeName, damageTaken);
            }
        });

        // Clean up telemetry state on disconnect
        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> {
            if (handler.getPlayer() instanceof PlayerTelemetryHolder holder) {
                holder.resetTelemetry();
            }
        });
    }

    /**
     * Resolves the specific name of the mob, projectile, or environmental thing that caused damage.
     */
    public static String resolveDamageTypeName(DamageSource source) {
        if (source == null) return "Unknown";

        // 1. Attacking entity (specific mob or player)
        if (source.getEntity() != null) {
            String name = source.getEntity().getName().getString();
            if (name != null && !name.isBlank()) {
                return name;
            }
        }

        // 2. Direct entity (projectile, falling block, primed TNT, etc.)
        if (source.getDirectEntity() != null) {
            String directName = source.getDirectEntity().getName().getString();
            if (directName != null && !directName.isBlank()) {
                return directName;
            }
        }

        // 3. Environmental hazards or damage type identifier
        return formatEnvironmentalDamageName(source.getMsgId());
    }

    /**
     * Formats environmental damage keys into clean, human-readable display names.
     */
    public static String formatEnvironmentalDamageName(String msgId) {
        if (msgId == null || msgId.isBlank()) {
            return "Unknown";
        }

        String key = msgId.contains(":") ? msgId.substring(msgId.indexOf(':') + 1) : msgId;

        return switch (key) {
            case "inFire", "onFire" -> "Fire";
            case "campfire" -> "Campfire";
            case "lava" -> "Lava";
            case "hotFloor" -> "Magma Block";
            case "inWall" -> "Suffocation";
            case "cramming" -> "Suffocation";
            case "drown" -> "Drowning";
            case "starve" -> "Starvation";
            case "cactus" -> "Cactus";
            case "fall" -> "Fall";
            case "flyIntoWall" -> "Kinetic Energy";
            case "outOfWorld" -> "The Void";
            case "generic", "genericKill" -> "Generic Damage";
            case "magic", "indirectMagic" -> "Magic";
            case "wither" -> "Wither";
            case "fallingStalactite", "stalagmite" -> "Pointed Dripstone";
            case "fallingBlock" -> "Falling Block";
            case "fallingAnvil" -> "Anvil";
            case "dryOut" -> "Dehydration";
            case "sweetBerryBush" -> "Sweet Berry Bush";
            case "freeze" -> "Freezing";
            case "lightningBolt" -> "Lightning Bolt";
            case "explosion", "explosion.player" -> "Explosion";
            case "badRespawnPoint" -> "Explosion";
            case "dragonBreath" -> "Dragon's Breath";
            case "sonic_boom" -> "Sonic Boom";
            case "mob" -> "Mob";
            case "player" -> "Player";
            case "arrow" -> "Arrow";
            case "trident" -> "Trident";
            case "fireball" -> "Fireball";
            case "witherSkull" -> "Wither Skull";
            case "thorns" -> "Thorns";
            default -> {
                String[] words = key.split("[_\\-\\s.]+");
                StringBuilder sb = new StringBuilder();
                for (String word : words) {
                    if (!word.isEmpty()) {
                        if (!sb.isEmpty()) sb.append(" ");
                        sb.append(Character.toUpperCase(word.charAt(0)));
                        if (word.length() > 1) {
                            sb.append(word.substring(1));
                        }
                    }
                }
                yield sb.isEmpty() ? key : sb.toString();
            }
        };
    }

    /**
     * Resolves a translatable or literal Component for any damage type identifier or formatted name.
     */
    public static Component getDamageTypeComponent(String msgId) {
        if (msgId == null || msgId.isBlank()) {
            return Component.translatable("death_telemetry.damage.unknown");
        }

        String key = msgId.contains(":") ? msgId.substring(msgId.indexOf(':') + 1) : msgId;

        return switch (key) {
            case "inFire", "onFire", "Fire" -> Component.translatable("death_telemetry.damage.fire");
            case "campfire", "Campfire" -> Component.translatable("death_telemetry.damage.campfire");
            case "lava", "Lava" -> Component.translatable("death_telemetry.damage.lava");
            case "hotFloor", "Magma Block" -> Component.translatable("death_telemetry.damage.magma_block");
            case "inWall", "cramming", "Suffocation" -> Component.translatable("death_telemetry.damage.suffocation");
            case "drown", "Drowning" -> Component.translatable("death_telemetry.damage.drowning");
            case "starve", "Starvation" -> Component.translatable("death_telemetry.damage.starvation");
            case "cactus", "Cactus" -> Component.translatable("death_telemetry.damage.cactus");
            case "fall", "Fall" -> Component.translatable("death_telemetry.damage.fall");
            case "flyIntoWall", "Kinetic Energy" -> Component.translatable("death_telemetry.damage.kinetic");
            case "outOfWorld", "The Void" -> Component.translatable("death_telemetry.damage.void");
            case "generic", "genericKill", "Generic Damage" -> Component.translatable("death_telemetry.damage.generic");
            case "magic", "indirectMagic", "Magic" -> Component.translatable("death_telemetry.damage.magic");
            case "wither", "Wither" -> Component.translatable("death_telemetry.damage.wither");
            case "fallingStalactite", "stalagmite", "Pointed Dripstone" -> Component.translatable("death_telemetry.damage.dripstone");
            case "fallingBlock", "Falling Block" -> Component.translatable("death_telemetry.damage.falling_block");
            case "fallingAnvil", "Anvil" -> Component.translatable("death_telemetry.damage.anvil");
            case "dryOut", "Dehydration" -> Component.translatable("death_telemetry.damage.dehydration");
            case "sweetBerryBush", "Sweet Berry Bush" -> Component.translatable("death_telemetry.damage.sweet_berry_bush");
            case "freeze", "Freezing" -> Component.translatable("death_telemetry.damage.freeze");
            case "lightningBolt", "Lightning Bolt" -> Component.translatable("death_telemetry.damage.lightning");
            case "explosion", "explosion.player", "badRespawnPoint", "Explosion" -> Component.translatable("death_telemetry.damage.explosion");
            case "dragonBreath", "Dragon's Breath" -> Component.translatable("death_telemetry.damage.dragon_breath");
            case "sonic_boom", "Sonic Boom" -> Component.translatable("death_telemetry.damage.sonic_boom");
            case "mob", "Mob" -> Component.translatable("death_telemetry.damage.mob");
            case "player", "Player" -> Component.translatable("death_telemetry.damage.player");
            case "arrow", "Arrow" -> Component.translatable("death_telemetry.damage.arrow");
            case "trident", "Trident" -> Component.translatable("death_telemetry.damage.trident");
            case "fireball", "Fireball" -> Component.translatable("death_telemetry.damage.fireball");
            case "witherSkull", "Wither Skull" -> Component.translatable("death_telemetry.damage.wither_skull");
            case "thorns", "Thorns" -> Component.translatable("death_telemetry.damage.thorns");
            default -> Component.literal(formatEnvironmentalDamageName(msgId));
        };
    }
}
