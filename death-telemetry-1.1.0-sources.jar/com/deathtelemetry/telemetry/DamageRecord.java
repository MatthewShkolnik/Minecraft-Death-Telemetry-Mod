package com.deathtelemetry.telemetry;

/**
 * Lightweight, compact record representing a damage source incident within a sample window.
 *
 * @param damageTypeId Identifier or translation key of the damage type (e.g., "fall", "lava", "player")
 * @param amount       Amount of damage taken in this incident
 */
public record DamageRecord(String damageTypeId, float amount) {
}
