package com.deathtelemetry.telemetry;

/**
 * Duck interface applied to ServerPlayerEntity via Mixin.
 * Provides access to the player's dedicated pre-mortem telemetry ring-buffer.
 */
public interface PlayerTelemetryHolder {
    /**
     * Retrieves the rolling ring-buffer attached to this player.
     */
    TelemetryRingBuffer getTelemetryBuffer();

    /**
     * Queues a damage event that occurred during the current sample interval.
     *
     * @param damageTypeId Name or registry identifier of the damage type (e.g. "fall", "lava")
     * @param amount       Actual damage amount applied to the player
     */
    void recordDamage(String damageTypeId, float amount);

    /**
     * Steps the telemetry sampler by one game tick.
     * Samples are committed into the ring-buffer at a fixed interval (e.g., every 10 ticks / 0.5s).
     */
    void tickTelemetry();

    /**
     * Forces an immediate telemetry snapshot to be recorded into the ring buffer.
     * Useful at the moment of death to guarantee the fatal state is recorded.
     */
    void forceSample();

    /**
     * Clears all recorded telemetry and pending damage.
     */
    void resetTelemetry();
}
