package com.deathtelemetry.telemetry;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

/**
 * Memory-efficient, circular ring-buffer designed to track rolling pre-mortem player telemetry.
 *
 * Performance Characteristics:
 * - Pre-allocates all {@link TelemetrySnapshot} slots on instantiation.
 * - Steady-state ticking does ZERO heap allocations; slots are updated in-place.
 * - Circular index arithmetic eliminates memory copying on rollover.
 * - Detached copies are created only when explicitly requested (e.g., at player death).
 */
public class TelemetryRingBuffer {
    /**
     * Default capacity: 20 snapshots.
     * At half-second intervals (every 10 ticks), 20 snapshots = 10 seconds of history.
     */
    public static final int DEFAULT_CAPACITY = 20;

    private final TelemetrySnapshot[] slots;
    private final int capacity;

    private int head = 0; // Index of the oldest element
    private int size = 0; // Current count of elements (0 <= size <= capacity)

    public TelemetryRingBuffer() {
        this(DEFAULT_CAPACITY);
    }

    public TelemetryRingBuffer(int capacity) {
        if (capacity <= 0) {
            throw new IllegalArgumentException("Ring buffer capacity must be greater than 0");
        }
        this.capacity = capacity;
        this.slots = new TelemetrySnapshot[capacity];

        // Pre-allocate every snapshot slot once to eliminate GC overhead during tick cycles
        for (int i = 0; i < capacity; i++) {
            this.slots[i] = new TelemetrySnapshot();
        }
    }

    /**
     * Records a new sample into the ring buffer in-place.
     * If the buffer is full, the oldest sample is overwritten and the head pointer advances.
     *
     * @param tick            Current server tick count
     * @param timestampMillis Epoch millisecond timestamp
     * @param health          Player's current health
     * @param xVelocity       Player's current X-axis velocity (delta X)
     * @param yVelocity       Player's current Y-axis velocity (delta Y)
     * @param zVelocity       Player's current Z-axis velocity (delta Z)
     * @return The updated {@link TelemetrySnapshot} slot, allowing caller to append damage events in-place.
     */
    public TelemetrySnapshot recordSample(long tick, long timestampMillis, float health, double xVelocity, double yVelocity, double zVelocity) {
        int writeIndex;

        if (size < capacity) {
            // Buffer is filling up
            writeIndex = (head + size) % capacity;
            size++;
        } else {
            // Buffer is full: overwrite the oldest slot at head and advance head
            writeIndex = head;
            head = (head + 1) % capacity;
        }

        TelemetrySnapshot slot = slots[writeIndex];
        slot.set(tick, timestampMillis, health, xVelocity, yVelocity, zVelocity);
        return slot;
    }

    public TelemetrySnapshot recordSample(long tick, long timestampMillis, float health, double yVelocity) {
        return recordSample(tick, timestampMillis, health, 0.0, yVelocity, 0.0);
    }

    /**
     * Iterates over all recorded snapshots in chronological order (oldest to newest)
     * without any memory allocations.
     *
     * @param action Consumer called for each active slot
     */
    public void forEachChronological(Consumer<TelemetrySnapshot> action) {
        for (int i = 0; i < size; i++) {
            int index = (head + i) % capacity;
            action.accept(slots[index]);
        }
    }

    /**
     * Exports a list of detached snapshots ordered from oldest to newest.
     * Used exclusively during death event serialization to avoid mutating data in-flight.
     *
     * @return Ordered list of detached snapshot copies
     */
    public List<TelemetrySnapshot> exportChronologicalSnapshots() {
        List<TelemetrySnapshot> list = new ArrayList<>(size);
        for (int i = 0; i < size; i++) {
            int index = (head + i) % capacity;
            list.add(slots[index].detachedCopy());
        }
        return list;
    }

    /**
     * Resets the buffer state.
     */
    public void clear() {
        this.head = 0;
        this.size = 0;
    }

    public int size() {
        return size;
    }

    public int capacity() {
        return capacity;
    }

    public boolean isEmpty() {
        return size == 0;
    }

    public boolean isFull() {
        return size == capacity;
    }
}
