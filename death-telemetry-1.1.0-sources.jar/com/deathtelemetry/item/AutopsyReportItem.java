package com.deathtelemetry.item;

import net.minecraft.ChatFormatting;
import net.minecraft.core.component.DataComponents;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.CustomData;
import net.minecraft.world.level.Level;

/**
 * The "Autopsy Report" (Black Box) item dropped upon player death.
 * Stores 15 seconds of pre-mortem telemetry data using Minecraft 26.3 Data Components (CustomData).
 * Right-clicking opens the client-side telemetry readout screen.
 */
public class AutopsyReportItem extends Item {
    public static final String NBT_KEY_TELEMETRY = "DeathTelemetry";
    public static final String NBT_KEY_VICTIM_NAME = "VictimName";
    public static final String NBT_KEY_DEATH_TIME = "DeathTimestamp";

    public static java.util.function.Consumer<ItemStack> CLIENT_USE_HANDLER = stack -> {};

    public AutopsyReportItem(Item.Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResult use(Level world, Player user, InteractionHand hand) {
        ItemStack stack = user.getItemInHand(hand);

        if (world.isClientSide()) {
            if (hasTelemetryData(stack)) {
                CLIENT_USE_HANDLER.accept(stack);
            } else {
                user.sendOverlayMessage(
                        Component.translatable("item.death_telemetry.autopsy_report.empty")
                                .withStyle(ChatFormatting.RED)
                );
            }
        }

        return InteractionResult.SUCCESS;
    }

    /**
     * Checks if this item stack contains serialized flight recorder telemetry via CUSTOM_DATA.
     */
    public static boolean hasTelemetryData(ItemStack stack) {
        if (stack.isEmpty()) return false;
        CustomData customData = stack.get(DataComponents.CUSTOM_DATA);
        return customData != null && customData.copyTag().contains(NBT_KEY_TELEMETRY);
    }

    /**
     * Retrieves the root telemetry NBT compound from the item stack's CUSTOM_DATA component.
     */
    public static CompoundTag getTelemetryData(ItemStack stack) {
        if (!hasTelemetryData(stack)) return null;
        CustomData customData = stack.get(DataComponents.CUSTOM_DATA);
        if (customData == null) return null;
        return customData.copyTag().getCompoundOrEmpty(NBT_KEY_TELEMETRY);
    }

    /**
     * Serializes telemetry data into the item stack using Minecraft 26.3 Data Components.
     */
    public static void setTelemetryData(ItemStack stack, CompoundTag telemetryData) {
        CustomData current = stack.get(DataComponents.CUSTOM_DATA);
        CompoundTag rootNbt = (current != null) ? current.copyTag() : new CompoundTag();
        rootNbt.put(NBT_KEY_TELEMETRY, telemetryData);
        stack.set(DataComponents.CUSTOM_DATA, CustomData.of(rootNbt));
    }
}
