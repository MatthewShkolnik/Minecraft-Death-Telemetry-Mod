package com.deathtelemetry.item;

import com.deathtelemetry.DeathTelemetryMod;
import net.fabricmc.fabric.api.creativetab.v1.CreativeModeTabEvents;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;

import java.util.function.Function;

/**
 * Item registry for Death Telemetry targeting Minecraft 26.3.
 */
public class ModItems {

    public static final Item AUTOPSY_REPORT = registerItem(
            "autopsy_report",
            properties -> new AutopsyReportItem(properties.stacksTo(1).rarity(Rarity.UNCOMMON))
    );

    /**
     * Registers an item complying with Minecraft 26.3 registry key requirements.
     */
    private static Item registerItem(String name, Function<Item.Properties, Item> itemFactory) {
        ResourceKey<Item> key = ResourceKey.create(
                Registries.ITEM,
                Identifier.fromNamespaceAndPath(DeathTelemetryMod.MOD_ID, name)
        );

        Item.Properties properties = new Item.Properties().setId(key);
        Item item = itemFactory.apply(properties);

        return Registry.register(BuiltInRegistries.ITEM, key, item);
    }

    public static void registerModItems() {
        DeathTelemetryMod.LOGGER.info("Registering items for {}", DeathTelemetryMod.MOD_ID);

        // Add to Tools creative tab
        CreativeModeTabEvents.modifyOutputEvent(CreativeModeTabs.TOOLS_AND_UTILITIES).register(entries -> {
            entries.accept(AUTOPSY_REPORT);
        });
    }
}
